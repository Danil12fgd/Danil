package com.example.flutter_crush

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
