import 'package:flutter_crush/model/row_col.dart';

class FromToRowCol {
  FromToRowCol({
    required this.from,
    required this.to,
  });

  final RowCol from;
  final RowCol to;
}
