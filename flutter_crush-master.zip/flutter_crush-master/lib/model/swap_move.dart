///
/// SwapMove
///
class SwapMove {
  final int row;
  final int col;

  const SwapMove({
    required this.row,
    required this.col,
  });
}
